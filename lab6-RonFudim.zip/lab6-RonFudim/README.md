[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/Wmu5iBUy)
# Lab6

- Add the `appsettings.json` from Lab 5 at the root of the `MauiFitness` directory

- Ensure that the fields are named as such:

  ```json
  {
    "Settings": {
      "CaloriesApiKey": "...",
      "CaloriesApiUrl": "...",
      "ActivitiesApiKey": "...",
      "ActivitiesApiUrl": "...",
      "FireBaseApiKey": "...",
      "FireBaseAuthDomain": "...",
      "FireBaseDbUrl": "..."
    }
  }
  
  ```

  

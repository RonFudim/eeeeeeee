﻿using Firebase.Database;
using Firebase.Database.Offline;
using MauiFitness.Interfaces;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace MauiFitness.Services
{
    public class DatabaseService<T> : IDataStore<T> where T : class, IHasUKey
    {
        public DatabaseService(Firebase.Auth.User user, string path, string BaseUrl, string customKey = "")
        {
            FirebaseOptions options = new FirebaseOptions()
            {
                AuthTokenAsyncFactory = async () => await user.GetIdTokenAsync()
            };
            var client = new FirebaseClient(BaseUrl, options);
            _realtimeDb =
                client.Child(path)
                .AsRealtimeDatabase<T>(customKey, "", StreamingOptions.LatestOnly, InitialPullStrategy.MissingOnly, true);
           

        }
        
        private readonly RealtimeDatabase<T> _realtimeDb;

        ObservableCollection<T> _items;


        public ObservableCollection<T> Items
        {
            get
            {
                if(_items == null)
                    Task.Run(() => LoadItems()).Wait();
                return _items;

            }
        }
        private async Task LoadItems()
        {
            var result = await GetItemsAsync();
            _items = new ObservableCollection<T>(result);
        }

        public async Task<bool> AddItemsAsync(T item)
        {
            try
            {
                item.Key = _realtimeDb.Post(item);
                _realtimeDb.Put(item.Key, item);

                Items.Add(item);
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return await Task.FromResult(false);
            }
            return await Task.FromResult(true);
        }

        public async Task<bool> DeleteItemsAsync(T item)
        {
            try
            {
                _realtimeDb.Delete(item.Key);
                Items.Remove(item);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return await Task.FromResult(false);
            }
            return await Task.FromResult(true);
        }
        public async Task<bool> UpdateItemsAsync(T item)
        {
            try
            {
                _realtimeDb.Put(item.Key, item);
                var idx = Items.IndexOf(Items.FirstOrDefault(x => x.Key == item.Key));
                Items[idx] = item;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return await Task.FromResult(false);
            }
            return await Task.FromResult(true);
        }
        public async Task<IEnumerable<T>> GetItemsAsync(bool forceRefresh =false)
        {
            if (_realtimeDb.Database?.Count == 0)
            {
                try
                {
                    
                    await _realtimeDb.PullAsync();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                    return null;
                }
            }
            IEnumerable<T> result = _realtimeDb.Once().Select(x => x.Object);
            return await Task.FromResult(result);

        }
    }
}

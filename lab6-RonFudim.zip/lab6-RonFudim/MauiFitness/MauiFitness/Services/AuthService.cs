﻿using Firebase;
using Firebase.Auth;
using Firebase.Auth.Providers;

namespace MauiFitness.Services
{
    public class AuthService
    {
        

        private static FirebaseAuthConfig config = new FirebaseAuthConfig()
        { 
            ApiKey = App.Settings.FireBaseApiKey,
            AuthDomain = App.Settings.FireBaseAuthDomain,
            Providers = new FirebaseAuthProvider[]
            {
                  new EmailProvider()
            },
        };
        public static FirebaseAuthClient client
        {
            get;
        }  = new FirebaseAuthClient(config);

        public static UserCredential UserCreds { get; set; }
    }

   
}


using MauiFitness.DataRepos;
using MauiFitness.Models;

namespace MauiFitness.Views;

public partial class MeasuresPage : ContentPage
{
	public MeasuresPage()
	{

        InitializeComponent();
      
    }
}
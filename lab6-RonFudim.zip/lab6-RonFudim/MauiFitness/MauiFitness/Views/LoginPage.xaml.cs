using Firebase.Auth;
using MauiFitness.Services;
using System.Diagnostics;

namespace MauiFitness.Views;

public partial class LoginPage : ContentPage
{
	public LoginPage()
	{
		InitializeComponent();

    }

    private async void BtnLogin_Clicked(object sender, EventArgs e)
    {
        lblError.Text = string.Empty;
        try
        {
            if (Connectivity.Current.NetworkAccess != NetworkAccess.Internet)
            {
                throw new Exception("No internet connection");

            }

            AuthService.UserCreds = await  AuthService.client.SignInWithEmailAndPasswordAsync(user_name.Text, password.Text);


            //Update UI
            lblUser.Text = $"ID    : {AuthService.UserCreds.User.Uid}\n" +
                            $"Email : {AuthService.UserCreds.User.Info.Email}";

            LoginView.IsVisible = false;
            HomeView.IsVisible = true;

            await DisplayAlert("Succes", "You are successfully login in", "Ok");

            await Shell.Current.GoToAsync($"//Index");
        }
        catch (FirebaseAuthException ex)
        {
            await DisplayAlert("Authentication error", "Wrong username or password", "OK");
            Debug.WriteLine(ex.Message);
        }
        catch (Exception ex)
        {
            await DisplayAlert("Alert", $"{ex.Message}", "OK");
            Debug.WriteLine(ex.Message);
        }
    }

    private async void LogoutBtn_Clicked(object sender, EventArgs e)
    {
        try
        {
            //Update UI
            lblUser.Text = string.Empty;
            HomeView.IsVisible = false;
            LoginView.IsVisible = true;
            AuthService.client.SignOut();
            await Shell.Current.GoToAsync($"//{nameof(LoginPage)}");
        }
        catch (Exception ex)
        {
            await DisplayAlert("Alert", ex.Message, "OK");
        }
    }

    private void Btn_Signup_Clicked(object sender, EventArgs e)
    {
        /// TODO: Create and push a SignupPage which takes user credentials 
        /// then calls AuthService.client.CreateUserWithEmailAndPasswordAsync(email, password);
        /// 
    }
}
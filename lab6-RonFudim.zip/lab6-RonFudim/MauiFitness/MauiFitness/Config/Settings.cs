﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiFitness.Config
{
    public class Settings
    {
        ///\ TODO: Add config string variables
        public string CaloriesApiKey { get; set; }
        public string CaloriesApiUrl { get; set; }

        public string ActivitiesApiKey { get; set; }
        public string ActivitiesApiUrl { get; set; }

        public string FireBaseApiKey { get; set; }
        public string FireBaseAuthDomain { get; set; }

        public string FireBaseDbUrl { get; set; }
    }
}

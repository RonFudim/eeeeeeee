﻿using MauiFitness.Models;
using MauiFitness.Services;
using System.Collections.Specialized;
using System.ComponentModel;


namespace MauiFitness.DataRepos
{
    public class FitnessRepo
    {
        
        public Weight WeightGoal { get; set; }
        public Weight CurrentWeight { get; set; }
        public List<Weight> WeightHistory { get; set; }

    

        public FitnessRepo(Firebase.Auth.User user, string databaseUrl)
        {
            mealsDb = new DatabaseService<Meal>(
                    user,
                    nameof(Meal),
                    databaseUrl,
                    nameof(Meal));
            

            workOutDB = new DatabaseService<Workout>(
                    user,
                    nameof(Workout),
                    databaseUrl,
                    nameof(Workout));

            // Added for lab 6
            WeightHistory = new List<Weight>();


        }


        private DatabaseService<Meal> mealsDb;

        public DatabaseService<Meal> MealsDb
        {
            get
            {
                return mealsDb;
            }
        }


        private DatabaseService<Workout> workOutDB;

        public DatabaseService<Workout> WorkOutDB
        {
            get
            {
                return workOutDB;
            }
        }

        private void AddTestData(int sample_points = 40)
        {
            WeightHistory = new List<Weight>();
            Weight weight;
            DateTime day;

            //First value is set to obesity level.
            WeightHistory.Add(
                new Weight(
                    Weight.ObesityLimit,
                    DateTime.Now.AddDays(-sample_points)
                    ));

            Random random = new Random();
            for (int i = 1; i < sample_points; i++)
            {
                var delta = random.NextDouble() - 0.75;
                var value = WeightHistory[i - 1].Value
                    + delta;
                day = DateTime.Now.AddDays(i - sample_points);
                weight = new Weight(value, day, Weight.WeightUnit.Kg);


                WeightHistory.Add(weight);
            }
            // setting the current weight and the goal
            CurrentWeight = WeightHistory[sample_points - 1];
            WeightGoal = new Weight(Weight.HealthyMax, DateTime.Now.AddDays(40));
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiFitness.Interfaces
{
    public interface IDataStore<T> 
    {
        Task<bool> AddItemsAsync(T item);
        Task<bool> UpdateItemsAsync(T item);
        Task<bool> DeleteItemsAsync(T item);
        Task<IEnumerable<T>> GetItemsAsync(bool forceRefresh = false);
        public ObservableCollection<T> Items { get; }
    }
}

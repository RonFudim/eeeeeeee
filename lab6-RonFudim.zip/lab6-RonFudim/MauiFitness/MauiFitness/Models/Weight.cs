﻿using System.ComponentModel;

namespace MauiFitness.Models
{

    public class Weight 
    {
       

        public static double HealthyMin = 65;
        public static double HealthyMax = 75;
        public static double ObesityLimit = 90;


        public enum WeightUnit
        {
            Kg,
            Ib
        }
        private double _value;
        private WeightUnit _unit;

        

        public double Value
        {
            get
            {
                return _value;
            }
            set
            {
                if (value > 0.0)
                {
                    _value = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException();
                }
            }
        }
        public WeightUnit Unit { 
            get { return _unit; }
            set { 
                if (!Enum.IsDefined(typeof(WeightUnit), value))
                {
                    throw new ArgumentOutOfRangeException();
                }
                else if(value != _unit)
                {
                    _unit = value;
                                   }

            } }

        public DateTime Time { get; set; }
        
        public Weight()
        {
            Value = 1.0;
            Unit = WeightUnit.Kg;
            Time = default;
        }
        public Weight(double value, DateTime time, WeightUnit unit = WeightUnit.Kg)
        {
            Value = value;
            Unit = unit;
            Time = time;
        }
    }
}

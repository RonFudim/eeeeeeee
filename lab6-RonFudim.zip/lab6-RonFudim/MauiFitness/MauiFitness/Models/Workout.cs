﻿using MauiFitness.Interfaces;
using System.ComponentModel;

namespace MauiFitness.Models
{    
    
    public class Workout : INotifyPropertyChanged, IHasUKey
    {
        public event PropertyChangedEventHandler PropertyChanged;
        string key;
        const double MINUTES_PER_HOUR = 60.0;
       public string Key { get => key; set => key = value; }

        public string Name { get; set; }

        public string Description { get; set; }

       
        public DateTime Time { get; set; }
        public TimeSpan Duration { get; set; }


        public double CalBurntPerHour { get; set; }

        public double Calories
        {
            get => (Duration.TotalMinutes/ MINUTES_PER_HOUR) * CalBurntPerHour;
        }
       

        //Copy method, for edit pusposes.
        public Workout Copy()
        {
            return new Workout()
            {
                Key= Key,
                Name = Name,
                Description = Description,
                Duration = Duration,
                CalBurntPerHour = CalBurntPerHour
            };
        }

    }
}
